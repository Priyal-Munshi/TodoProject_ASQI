from django.urls import path
from . import views

urlpatterns = [
    path('',views.display_todo,name='display'),
    path('',views.add_todo,name='add'),
    path('',views.delete_todo,name='delete'),
    path('',views.login,name='display'),
    path('',views.register,name='display'),


]