from django.db import models
import uuid


class Introduction(models.Model):
	created_at = models.DateTimeField(auto_now_add=True)
	name = models.CharField(max_length=50)
	email =  models.CharField(max_length=50)
	phone =  models.CharField(max_length=100)
	title = models.TextField()
	description = models.TextField()
	id = models.UUIDField(default=uuid.uuid4, unique=True, primary_key=True, editable=False)
	