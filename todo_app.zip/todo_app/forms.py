from django.forms import ModelForm
from .models import Introduction

class IntroductionForm(ModelForm):
    class Meta:
        model = Introduction
        fields = ['name', 'email','phone','title','description']

       

    def __init__(self, *args, **kwargs):
        super(IntroductionForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update(
                {'class': 'input'})