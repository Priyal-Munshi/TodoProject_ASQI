from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import IntroductionForm
from .models import Introduction
from django.contrib.auth.models import User
from django.contrib import auth


# --------------------read---------------------
def display_todo(request, pk):
	if request.user.is_authenticated:
		todo_display = Introduction.objects.get(id=pk)
		return render(request, 'home.html', {'todo_display':todo_display})
	else:
		messages.success(request, "You Must Be Logged In To view the page...")
		return redirect('home')

# ------------------------create--------------------
def add_todo(request):
	form = IntroductionForm(request.POST or None)
	if request.user.is_authenticated:
		if request.method == "POST":
			if form.is_valid():
				form.save()
				messages.success(request, "TodoItem Added...")
				return redirect('home')
		return render(request, 'home.html', {'form':form})
	else:
		messages.success(request, "You Must Be Logged In...")
		return redirect('home')
      
# -----------------------delete--------------------
def delete_todo(request, pk):
	if request.user.is_authenticated:
		delete_todo = Introduction.objects.get(id=pk)
		delete_todo.delete()
		messages.success(request, "TodoItem Deleted Successfully...")
		return redirect('home')
	else:
		messages.success(request, "You Must Be Logged In To Do That...")
		return redirect('home')



	
# --------------------------------------------authentication---------------------------------

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = auth.authenticate(request, username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('home')
        else:
            error_message = 'Invalid username or password'
            return render(request, 'home.html', {'error_message':error_message})
    else:      
        return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            try:
                user = User.objects.create_user(username, email, password1)
                user.save()
                auth.login(request, user)
                return redirect('home')
            except:
                error_message = 'Error creating user'
                return render(request, 'home.html', {'error_message':error_message})

        else:
            error_message = 'Password does not match'
            return render(request, 'home.html', {'error_message':error_message})

    return render(request, 'home.html')

def logout(request):
    auth.logout(request)
    return redirect('home')